#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr  9 10:56:15 2021

@author: rg
"""
import Download

def main():
    Download.download_song()
    
if __name__ == '__main__':
    main()